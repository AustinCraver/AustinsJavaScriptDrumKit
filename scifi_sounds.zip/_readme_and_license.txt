Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - NHumphrey ( https://freesound.org/people/NHumphrey/ )

You can find this pack online at: https://freesound.org/people/NHumphrey/packs/13052/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 204456__nhumphrey__blaster-04.wav
    * url: https://freesound.org/s/204456/
    * license: Creative Commons 0
  * 204455__nhumphrey__blaster-03.wav
    * url: https://freesound.org/s/204455/
    * license: Creative Commons 0
  * 204444__nhumphrey__blaster-02.wav
    * url: https://freesound.org/s/204444/
    * license: Creative Commons 0
  * 204433__nhumphrey__blaster-01.wav
    * url: https://freesound.org/s/204433/
    * license: Creative Commons 0
  * 204432__nhumphrey__spooky-alien-language-04.wav
    * url: https://freesound.org/s/204432/
    * license: Creative Commons 0
  * 204422__nhumphrey__spooky-alien-language-03.wav
    * url: https://freesound.org/s/204422/
    * license: Creative Commons 0
  * 204421__nhumphrey__spooky-alien-language-02.wav
    * url: https://freesound.org/s/204421/
    * license: Creative Commons 0
  * 204420__nhumphrey__spooky-alien-language-01.wav
    * url: https://freesound.org/s/204420/
    * license: Creative Commons 0
  * 204419__nhumphrey__ufo-02.wav
    * url: https://freesound.org/s/204419/
    * license: Creative Commons 0
  * 204418__nhumphrey__large-engine.wav
    * url: https://freesound.org/s/204418/
    * license: Creative Commons 0
  * 204417__nhumphrey__ufo.wav
    * url: https://freesound.org/s/204417/
    * license: Creative Commons 0


